import { createBrowserRouter } from "react-router";
import { Dashboard } from "./screens/Dashboard";
import { AddSubscription } from "./screens/AddSubscription";
import { Analytics } from "./screens/Analytics";
import { History } from "./screens/History";
import { Reminders } from "./screens/Reminders";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Dashboard,
  },
  {
    path: "/analytics",
    Component: Analytics,
  },
  {
    path: "/add",
    Component: AddSubscription,
  },
  {
    path: "/history",
    Component: History,
  },
  {
    path: "/reminders",
    Component: Reminders,
  },
]);
