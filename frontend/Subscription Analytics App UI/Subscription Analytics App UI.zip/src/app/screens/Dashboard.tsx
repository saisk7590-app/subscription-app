import { AlertCircle, Tv, Smartphone, Wifi, Satellite } from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';
import { MobileContainer } from '../components/MobileContainer';
import { BottomNav } from '../components/BottomNav';
import { subscriptions } from '../data/mockData';

export function Dashboard() {
  const currentMonth = new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' });

  // Calculate total yearly spending
  const totalYearlySpending = subscriptions.reduce((sum, sub) => {
    if (sub.billingType === 'Monthly') {
      return sum + (sub.price * 12);
    } else if (sub.billingType === 'Yearly') {
      return sum + sub.price;
    }
    return sum + sub.price;
  }, 0);

  // Calculate category totals (yearly)
  const categoryTotals = {
    OTT: 0,
    SIM: 0,
    WiFi: 0,
    DTH: 0
  };

  subscriptions.forEach(sub => {
    const yearlyPrice = sub.billingType === 'Monthly' ? sub.price * 12 : sub.price;

    if (sub.category === 'OTT') {
      categoryTotals.OTT += yearlyPrice;
    } else if (sub.category === 'Mobile') {
      categoryTotals.SIM += yearlyPrice;
    } else if (sub.category === 'Internet') {
      categoryTotals.WiFi += yearlyPrice;
    } else if (sub.category === 'DTH') {
      categoryTotals.DTH += yearlyPrice;
    }
  });

  // Calculate category distribution
  const categoryData = subscriptions.reduce((acc: any[], sub) => {
    const existing = acc.find(item => item.name === sub.category);
    const monthlyPrice = sub.billingType === 'Yearly' ? sub.price / 12 : sub.price;
    
    if (existing) {
      existing.value += monthlyPrice;
    } else {
      acc.push({ name: sub.category, value: monthlyPrice, id: sub.category });
    }
    return acc;
  }, []);

  // Top 5 categories
  const topCategories = categoryData
    .sort((a, b) => b.value - a.value)
    .slice(0, 5);

  const COLORS = ['#3b82f6', '#8b5cf6', '#06b6d4', '#10b981', '#f59e0b'];

  // Top services
  const topServices = subscriptions
    .map(sub => ({
      ...sub,
      monthlyPrice: sub.billingType === 'Yearly' ? sub.price / 12 : sub.price
    }))
    .sort((a, b) => b.monthlyPrice - a.monthlyPrice)
    .slice(0, 3);

  // Calculate days until next due
  const getDaysUntil = (dateString: string) => {
    const today = new Date();
    const dueDate = new Date(dateString);
    const diffTime = dueDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const upcomingDue = subscriptions.find(sub => {
    const days = getDaysUntil(sub.nextDueDate);
    return days > 0 && days <= 7;
  });

  return (
    <MobileContainer>
      {/* Header */}
      <div className="bg-gradient-to-br from-blue-500 to-purple-600 px-6 pt-8 pb-6 rounded-b-3xl">
        <h1 className="text-white text-2xl font-semibold">Hello, Sai</h1>
        <p className="text-blue-100 text-sm mt-1">{currentMonth}</p>
      </div>

      <div className="px-4 -mt-4 space-y-6">
        {/* Total Yearly Spending Card - Main KPI */}
        <div className="bg-white rounded-2xl p-8 shadow-md">
          <p className="text-gray-500 text-sm mb-2">Total Yearly Spending</p>
          <p className="text-5xl font-bold text-gray-900">₹{Math.round(totalYearlySpending).toLocaleString()}</p>
        </div>

        {/* Category KPI Cards Row */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-white rounded-xl p-4 shadow-sm">
            <div className="flex items-center gap-2 mb-2">
              <div className="bg-blue-100 p-2 rounded-lg">
                <Tv className="w-4 h-4 text-blue-600" />
              </div>
              <p className="text-xs text-gray-500">OTT</p>
            </div>
            <p className="text-xl font-bold text-gray-900">₹{Math.round(categoryTotals.OTT).toLocaleString()}</p>
          </div>

          <div className="bg-white rounded-xl p-4 shadow-sm">
            <div className="flex items-center gap-2 mb-2">
              <div className="bg-purple-100 p-2 rounded-lg">
                <Smartphone className="w-4 h-4 text-purple-600" />
              </div>
              <p className="text-xs text-gray-500">SIM</p>
            </div>
            <p className="text-xl font-bold text-gray-900">₹{Math.round(categoryTotals.SIM).toLocaleString()}</p>
          </div>

          <div className="bg-white rounded-xl p-4 shadow-sm">
            <div className="flex items-center gap-2 mb-2">
              <div className="bg-cyan-100 p-2 rounded-lg">
                <Wifi className="w-4 h-4 text-cyan-600" />
              </div>
              <p className="text-xs text-gray-500">WiFi</p>
            </div>
            <p className="text-xl font-bold text-gray-900">₹{Math.round(categoryTotals.WiFi).toLocaleString()}</p>
          </div>

          <div className="bg-white rounded-xl p-4 shadow-sm">
            <div className="flex items-center gap-2 mb-2">
              <div className="bg-green-100 p-2 rounded-lg">
                <Satellite className="w-4 h-4 text-green-600" />
              </div>
              <p className="text-xs text-gray-500">DTH</p>
            </div>
            <p className="text-xl font-bold text-gray-900">₹{Math.round(categoryTotals.DTH).toLocaleString()}</p>
          </div>
        </div>

        {/* Alert Card */}
        {upcomingDue && (
          <div className="bg-red-50 border border-red-200 rounded-xl p-4 flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-red-500 mt-0.5 flex-shrink-0" />
            <div>
              <p className="text-red-900 font-medium">{upcomingDue.serviceName} due in {getDaysUntil(upcomingDue.nextDueDate)} days</p>
              <p className="text-red-700 text-sm mt-0.5">₹{upcomingDue.price} • {upcomingDue.nextDueDate}</p>
            </div>
          </div>
        )}

        {/* Category Distribution */}
        <div className="bg-white rounded-2xl p-5 shadow-sm">
          <h2 className="text-gray-900 font-semibold mb-3">Category Distribution</h2>
          <div className="h-40 mb-3">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={topCategories}
                  cx="50%"
                  cy="50%"
                  innerRadius={40}
                  outerRadius={65}
                  paddingAngle={2}
                  dataKey="value"
                >
                  {topCategories.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="space-y-2">
            {topCategories.slice(0, 4).map((category, index) => (
              <div key={category.name} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: COLORS[index % COLORS.length] }}
                  />
                  <span className="text-sm text-gray-700">{category.name}</span>
                </div>
                <span className="text-sm font-medium text-gray-900">
                  ₹{Math.round(category.value).toLocaleString()}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Top Services */}
        <div className="bg-white rounded-2xl p-5 shadow-sm">
          <h2 className="text-gray-900 font-semibold mb-4">Top Services</h2>
          <div className="space-y-3">
            {topServices.map((service) => (
              <div key={service.id} className="flex items-center justify-between py-2">
                <div>
                  <p className="text-gray-900 font-medium">{service.serviceName}</p>
                  <p className="text-gray-500 text-sm">{service.category}</p>
                </div>
                <p className="text-gray-900 font-semibold">
                  ₹{service.billingType === 'Yearly' ? Math.round(service.price / 12) : service.price}
                  <span className="text-gray-500 text-xs font-normal">/mo</span>
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>

      <BottomNav />
    </MobileContainer>
  );
}